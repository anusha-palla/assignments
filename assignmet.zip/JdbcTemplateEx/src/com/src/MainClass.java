package com.src;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext con=new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee e=(Employee) con.getBean("emp");
		EmpDao ed=(EmpDao) con.getBean("empdao");
		int i=ed.saveEmp(e);
		if(i>0)
		{
			System.out.println("inserted");
		}
		else
		{
			System.out.println(" not inserted");
		}
		System.out.println("updated");
		ed.update(12,99999);
		System.out.println("deleted");
		ed.delete(13);

	}

}
