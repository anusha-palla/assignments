package com.src;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmpDao {
	JdbcTemplate jdbctemplate;

	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	public int saveEmp(Employee e)
	{
		String query="insert into somedetails values("+e.getId()+",'"+e.getName()+"','"+e.getAddr()+"',"+e.getMobile()+")";
		return jdbctemplate.update(query);
	}
	public void update(int id,long mobile)
	{
		String sql="update somedetails set mobile=? where id=?";
		jdbctemplate.update(sql,mobile,id);
		System.out.println("updated "+id);
	}
	public void delete(int id)
	{
		String sql="delete from somedetails where id=?";
		jdbctemplate.update(sql,id);
		System.out.println("deleted "+id);
	}

}