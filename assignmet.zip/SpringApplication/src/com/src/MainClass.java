package com.src;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource re=new ClassPathResource("applicationContext.xml");
		BeanFactory fa=new XmlBeanFactory(re);
		Student s=(Student) fa.getBean("stu1");
		System.out.println(s);

	}

}
