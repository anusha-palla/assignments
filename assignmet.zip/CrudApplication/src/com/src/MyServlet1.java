package com.src;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.DriverManager;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
/**
 * Servlet implementation class MyServlet1
 */
public class MyServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		ServletContext sc=getServletContext();
		Connection con=(Connection) sc.getAttribute("myConnection");
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String address=request.getParameter("addr");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		
		try {
			//Statement st=con.createStatement();
			PreparedStatement ps=con.prepareStatement("insert into somedetails values(?,?,?,?)");
			ps.setInt(1,id);
			ps.setString(2,name);
			ps.setString(3,address);
			ps.setLong(4, mobile);
			int i=ps.executeUpdate();
			if(i>0)
			{
				pw.print("inserterd");
			}
			else
			{
				pw.print("not inserted");
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		pw.print("<form action=\"./delete\">\r\n" +  
				"<input type=\"submit\" value=\"delete\"/>\r\n" + 
				"</form>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
