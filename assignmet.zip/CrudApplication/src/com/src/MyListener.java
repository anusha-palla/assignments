package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Application Lifecycle Listener implementation class MyListener
 *
 */
public class MyListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public MyListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	try {
    		 Class.forName("com.mysql.cj.jdbc.Driver");
					 Connection con = DriverManager.getConnection(
					        "jdbc:mysql://localhost:3306/some", "root", "Smily@$123456");
	            ServletContext ctx=sce.getServletContext();
	            ctx.setAttribute("myConnection",con);
    	}
    	catch(ClassNotFoundException |SQLException e)
    	{
    		e.printStackTrace();
    	}
    }
	
}
