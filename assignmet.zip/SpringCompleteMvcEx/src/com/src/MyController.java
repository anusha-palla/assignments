package com.src;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@RequestMapping("/validate")
 public String validate(@RequestParam("uname")String user,@RequestParam("pwd")String pwd,Model m) 
	{
		String msg=null;
		if(user.equals(pwd))
		{
			msg="welcome to "+user;
			m.addAttribute("message",msg);
			return "success";
		}
		else
		{
			msg="invalid";
			m.addAttribute("message",msg);
			return "index";
		}
	}
 
}
