package com.src;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Customer c=(Customer) context.getBean("cus1");
		System.out.println(c.getCid()+" "+c.getCname()+" "+c.getCdd().getHno()+ " "+c.getCdd().getStreetname()+" "+c.getCdd().getCity());
		

	}

}
