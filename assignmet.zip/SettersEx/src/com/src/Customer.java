package com.src;

public class Customer {
	private int cid;
	private String cname;
	private Address cdd;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Address getCdd() {
		return cdd;
	}
	public void setCdd(Address cdd) {
		this.cdd = cdd;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
