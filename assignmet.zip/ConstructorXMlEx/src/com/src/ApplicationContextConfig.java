package com.src;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationContextConfig {
	@Bean(name="some")
	public Student getStudent() {
		int sid=20;
		String sname="some";
		String sadd="some1";
		return new Student(sid,sname,sadd);
	}

}
