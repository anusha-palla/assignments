package com.src;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
public class Student {
	private int sid;
	private String sname;
	private String sadd;
	Student()
	{
		
	}
	public Student(int sid, String sname, String sadd) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sadd = sadd;
	}
	public Student(int sid, String sname) {
		super();
		this.sid = sid;
		this.sname = sname;
	}
	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + "]";
	}
	public int getSid() {
		return sid;
	}
	public String getSname() {
		return sname;
	}
	public String getSadd() {
		return sadd;
	}
	
}
