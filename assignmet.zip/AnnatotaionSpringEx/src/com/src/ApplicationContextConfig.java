package com.src;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationContextConfig {
	int id;
	String name;
	@Bean(name="some")
	public StudentEx getStudentEx() {
		id=11;
		name="abc";
		 return new StudentEx(id,name);
	}
	@Bean(name="some1")
	public StudentEx getStudentEx1() {
		int id=12;
		 String name="anu";
		StudentEx s=new StudentEx();
		s.setId(id);
		s.setName(name);
		 return new StudentEx(id,name);
	}
 
}
