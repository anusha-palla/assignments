package com.src;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
		StudentEx s1=(StudentEx) context.getBean("some");
		System.out.println(s1);
		StudentEx s2=(StudentEx) context.getBean("some1");
		System.out.println(s2);

	}

}
