package com.src;

public class Employee {
	private int eid;
	private  String ename;
	private Address address;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void dispaly()
	{
		System.out.println(eid+" "+ename+" "+address.display());
	}
	

}
