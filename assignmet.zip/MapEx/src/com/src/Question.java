package com.src;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Question {
	private int qid;
	private String qname;
	private Map<String,String> answers;
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getQname() {
		return qname;
	}
	public void setQname(String qname) {
		this.qname = qname;
	}
	public Map<String, String> getAnswers() {
		return answers;
	}
	public void setAnswers(Map<String, String> answers) {
		this.answers = answers;
	}
	public void display()
	{
		System.out.println(qid+ " "+qname);
		Set<Entry<String,String>> set=answers.entrySet();
		Iterator<Entry<String,String>> it=set.iterator();
		while(it.hasNext())
		{
			Entry<String,String> e=it.next();
			System.out.println(e.getKey()+" "+e.getValue());
		}
		
		
		
		
	}

}
