package com.src;

public class Employee {
	private int eid;
	private String ename;
	private double esal;
	private Address address;
	public Employee(int eid, String ename, double esal, Address address) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		this.address = address;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void displayEmployee()
	{
		System.out.println(eid+" "+ename+" "+esal+" "+address.display());
	}
	public Employee(int eid, String ename, double esal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
	}
	

}
