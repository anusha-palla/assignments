package com.src;

public class Address {
	private String hno;
	private String state;
	private String country;
	public Address(String hno, String state, String country) {
		super();
		this.hno = hno;
		this.state = state;
		this.country = country;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String display() {
		return hno+" "+state+" "+country;
	}
	
 
}
