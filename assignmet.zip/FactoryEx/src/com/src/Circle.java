package com.src;

public class Circle implements Shape{
	public void draw()
	{
		System.out.println("Draw circle");
	}

}
