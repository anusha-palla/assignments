package com.src;

public interface Shape {
	public void draw();

}
