package com.src;

public class FactoryClass {
	public static Shape getShape()
	{
		return new Circle();
	}
	public static Shape getShape1()
	{
		return new Rectangle();
	}

}
