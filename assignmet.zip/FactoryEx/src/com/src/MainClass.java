package com.src;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext con=new ClassPathXmlApplicationContext("applicationContext.xml");
		Circle c=(Circle)con.getBean("some");
		c.draw();
		Rectangle c1=(Rectangle)con.getBean("some1");
		c1.draw();

	}

}
