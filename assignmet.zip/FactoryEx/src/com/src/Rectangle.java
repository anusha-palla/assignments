package com.src;

public class Rectangle implements Shape {
	public void draw()
	{
		System.out.println("Draw rectable");
	}

}
