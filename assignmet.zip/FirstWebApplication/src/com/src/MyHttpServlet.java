package com.src;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyHttpServlet
 */
public class MyHttpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyHttpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("uname");
		String rusername=request.getParameter("runame");
		String password=request.getParameter("pwd");
		ServletConfig config=getServletConfig();  
	    String s=config.getInitParameter("driverclass");  
	    ServletContext context=getServletContext();  
	    String gf=context.getInitParameter("somename"); 
	    
	    try {
			Class.forName(s);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		boolean r1=MyServletLogic.validate(username,rusername);
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		if(r1) {
		boolean r=MyServletLogic.validate(username, password);
		
		if(r)
			pw.print("hi this is "+username);
		else
			pw.print("invalid login");
		}
		else
		{
			pw.print("both user names are not valid");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
