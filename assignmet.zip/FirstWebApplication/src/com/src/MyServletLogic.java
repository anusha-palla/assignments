package com.src;

public class MyServletLogic {
	public static boolean validate(String username,String password)
	{
		return username.equals(password);
	}

}
